<?php
ini_set('display_errors', "On");
error_reporting(E_ALL);
session_start();
function h($str) {
    return htmlspecialchars($str, ENT_QUOTES, "UTF-8");
}
$pdo = new PDO("sqlite:question.sqlite");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
$st = $pdo->query("SELECT * FROM content ORDER BY id DESC;");
$data = $st->fetchAll();
?>
<!DOCTYPE html>
<html lang="ja">
<style>
    table,td{border:solid 1px; border-collapse:collapse;}
</style>
<head>
    <meta charset="utf-8">
    <title>question</title>
</head>

<body>
    <table>
<?php
 print "<tr><td>名前</td>\n<td>メールアドレス</td>\n<td>時間</td>\n<td>内容</td></tr>\n";
 print "<br>";
foreach ($data as $content) {
    print "<tr><td>" . h($content["name"]) . "</td>\n";
    print "<td>" . h($content["mail"]) . "</td>\n";
    print "<td>" . h($content["time"]) . "</td>\n";
    print "<td>" . h($content["message"]) . "</td></tr>\n";
}
?>
</table>
</body>
</html>
