<?php
 function h($str) { return htmlspecialchars($str, ENT_QUOTES, "UTF-8"); }
 session_start();
?>
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>問い合わせ</title>
  <link rel="stylesheet" type="text/css" href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/reset.css">
  <link rel="stylesheet" type="text/css" href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/5-1-26/css/5-1-26.css">
  <link rel="stylesheet" href="question_form.css">
  <link rel="stylesheet" href="top-style.css">
</head>
<body>
<header id="header">
    <h1>UniConnect</h1>
    <nav id="g-nav">
      <ul>
        <!-- 各リンクのhref属性を別のプログラムに変更 -->
        <li><a href="top-page.php">Home</a></li>
        <li><a href="rakutennbook.php">Book</a></li>
        <li><a href="ToDo.php">To Do List</a></li>
        <li><a href="timeTable.php">Schedule</a></li>
        <li><a href="question_form.php">Contact</a></li>
      </ul>
    </nav>
    
  </header>
  <main>
    <section>
<h2 class="heading-031">お問い合わせ</h2>
<form action="question_submit.php" method="post">
    <p><label class="textbox-002-label">お名前</label><input type="text" name="name" class="textbox-002"></p>
    <p><label class="textbox-002-label">メールアドレス</label><input type="text" name="mail" class="textbox-002"></p>
    <p><textarea name="message" id="message" cols="30" rows="7" class="textbox-002" placeholder="メッセージを入力してください" required=""></textarea></p>
    <input type="submit" value="送信" class="button_solid017">
</form>
</section>
</main>
</body>
</html>
