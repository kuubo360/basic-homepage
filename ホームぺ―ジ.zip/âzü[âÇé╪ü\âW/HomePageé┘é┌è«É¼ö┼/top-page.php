<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="utf-8">
  <title>トップページ</title>
  <meta name="description" content="書籍「動くWebデザインアイディア帳」のサンプルサイトです">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!--==============レイアウトを制御する独自のCSSを読み込み===============-->
  <link rel="stylesheet" type="text/css" href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/reset.css">
  <link rel="stylesheet" type="text/css" href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/5-1-26/css/5-1-26.css">
  <link rel="stylesheet" href="top-style.css">
  <link rel="stylesheet" href="top-page.css">
</head>
<body>
  <header id="header">
    <h1>UniConnect</h1>
    <nav id="g-nav">
      <ul>
        <!-- 各リンクのhref属性を別のプログラムに変更 -->
        <li><a href="top-page.php">Home</a></li>
        <li><a href="rakutennbook.php">Book</a></li>
        <li><a href="ToDo.php">To Do List</a></li>
        <li><a href="timeTable.php">Schedule</a></li>
        <li><a href="question_form.php">Contact</a></li>
      </ul>
    </nav>
    
  </header>
  <figure class="image"><img src="univers.jpg" width="100%"/></figure>
  <main>
    <section class="scroll-point" id="area-1">
    <div class="container">
      <div class="header">
        <h2 class="heading-031">大学生活をより充実させよう！</h2>
      </div>
      <div class="Book">
        <h1>01 Book</h1>
        <p>勉強に詰まった時、参考書を使いたい場面が出て来ると思います。<br>ここでは参考書検索をすることができます！<br>気に入ったものがあれば購入サイトにとべるので、すぐに購入することができます。<br>勉強に詰まった際にはぜひ使ってみてください！<br><br></p>
        <div style="text-align: center;"><img src="book.webp" width="80%"/></div>
      </div>
      <div class="ToDoList">
        <h1>02 To Do List</h1>
        <p>課題や発表準備などやることが多くて覚えきれないことはありませんか？<br>そんなときはこのTo Do Listを使ってみてください！<br>終わったものから消していき、やることを終わらせましょう。<br><br></p>
        <div style="text-align: center;"><img src="list.webp" width="80%"/></div>
      </div>
      <div class="Schedule">
        <h1>03 Schedule</h1>
        <p>大学生活に時間割は必須です。<br>自分の履修する授業を登録し、自分の時間割を見れるようにしましょう！<br>また、時間割表の授業をクリックするとコメントも追加できるようになっています。<br>ぜひ活用してみてください！<br><br></p>
        <div style="text-align: center;"><img src="schedule1.webp" width="80%"/></div>
      </div>
    </div>
  </main>

  <footer id="footer">
    <small>&copy; copyright.</small>  
  </footer>


  <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
  <script src="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/5-1-26/js/5-1-26.js"></script>
  <script>
    document.addEventListener("DOMContentLoaded", function () {
  // スクロール位置を監視する要素
  var scrollPoint = document.querySelector(".scroll-point");

  // スクロールイベントのリスナー
  window.addEventListener("scroll", function () {
    // スクロール位置を取得
    var scrollPosition = window.scrollY;
    
    // スクロール位置が特定のエリアに達したらアニメーションを追加
    if (scrollPosition >= scrollPoint.offsetTop - window.innerHeight) {
      // スクロール位置が特定のエリアに達したらアニメーションクラスを追加
      document.querySelector(".container").classList.add("animate");
    }
  });
});
</script>
</body>
</html>
