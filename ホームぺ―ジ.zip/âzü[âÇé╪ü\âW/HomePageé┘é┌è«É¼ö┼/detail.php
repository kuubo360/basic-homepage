<!DOCTYPE html>
<html lang="ja">
<?php
function h($str) { return htmlspecialchars($str, ENT_QUOTES, "UTF-8"); }
$pdo = new PDO("sqlite:tb.sqlite");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
$st = $pdo->query("SELECT * FROM tb");
$data = $st->fetchAll();
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Table with Links</title>

    <meta name="description" content="書籍「動くWebデザインアイディア帳」のサンプルサイトです">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!--==============レイアウトを制御する独自のCSSを読み込み===============-->
  <link rel="stylesheet" type="text/css" href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/reset.css">
  <link rel="stylesheet" type="text/css" href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/5-1-26/css/5-1-26.css">
  <link rel="stylesheet" href="top-style.css">
  <link rel="stylesheet" href="schedule.css">
  <style>
        /* テーブル全体のスタイル */
        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }

        /* テーブルのセル共通のスタイル */
        td, th {
            border: 1px solid #dddddd;
            text-align: center;
            padding: 8px;
        }

        /* テーブルのヘッダーのスタイル */
        th {
            background-color: #f2f2f2;
        }

        /* テーブルのリンクのスタイル */
        td a {
            color: #0066cc;
            text-decoration: none;
        }

        td a:hover {
            text-decoration: underline;
        }

        /* テーブルのセルの背景色を交互に変更する */
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
<header id="header">
    <h1>UniConnect</h1>
    <nav id="g-nav">
      <ul>
        <!-- 各リンクのhref属性を別のプログラムに変更 -->
        <li><a href="top-page.php">Home</a></li>
        <li><a href="rakutennbook.php">Book</a></li>
        <li><a href="ToDo.php">To Do List</a></li>
        <li><a href="timeTable.php">Schedule</a></li>
        <li><a href="question_form.php">Contact</a></li>
      </ul>
    </nav>
    
  </header>
<main>
  <section>
  <h2 class="heading-031">Time Schedule</h2>
<?php
if (isset($_GET['row']) && isset($_GET['col'])) {
    $row = $_GET['row'];
    $col = $_GET['col'];

    // フィルタリングされたデータ
    $filteredData = array_filter($data, function ($item) use ($row, $col) {
        return $item['number'] == $row && $item['week'] == $col;
    });

    if (!empty($filteredData)) {
        echo "<table border='1'>";
        echo "<tr><th>ID</th><th>Name</th><th>Week</th><th>Number</th><th>Teacher</th><th>Place</th></tr>";

        foreach ($filteredData as $filteredRow) {
            echo "<tr>";
            echo "<td>" . h($filteredRow['id']) . "</td>";
            echo "<td>" . h($filteredRow['name']) . "</td>";
            echo "<td>" . h($filteredRow['week']) . "</td>";
            echo "<td>" . h($filteredRow['number']) . "</td>";
            echo "<td>" . h($filteredRow['teacher']) . "</td>";
            echo "<td>" . h($filteredRow['place']) . "</td>";
          //  echo "<td>" . h($filteredRow['type']) . "</td>";
            echo "</tr>";
        }

        echo "</table>";

        // コメント表示       
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
        $st = $pdo->query("SELECT * FROM comment1 ");
        $data = $st->fetchAll();
        $st = $pdo->query("SELECT * FROM comment1 WHERE classId ='{$filteredRow['id']}';");
        if (!empty($st)) {
            echo "<br><h2>コメント</h2>";
            echo "<ul>";
            foreach ($st as $comment) {
                echo "<li>" . h($comment['text']) . "</li>";
            }
            echo "</ul>";
        } else {
            echo "<p>コメントはありません。</p>";
        }
    } else {
        echo "<p>No matching data found.</p>";
    }
} else {
    echo "<p>No matching data found.</p>";
}
echo '<br><a href="commentForm.php?classId=' . h($filteredRow['id']) . '">コメントする</a>';
?>
<a href="timeTable.php">トップに戻る</a>
</section>
</main>
<footer id="footer">
    <small>&copy; copyright.</small>  
  </footer>
</body>
</html>
