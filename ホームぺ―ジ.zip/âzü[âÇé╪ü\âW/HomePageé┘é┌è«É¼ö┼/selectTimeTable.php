<!DOCTYPE html>
<html lang="ja">
<?php
function h($str) { return htmlspecialchars($str, ENT_QUOTES, "UTF-8"); }
$pdo = new PDO("sqlite:tb.sqlite");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
$st = $pdo->query("SELECT * FROM tb");
$data = $st->fetchAll();
?>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['id'])) {
    $id = $_POST['id'];

    // データベースに接続
    $pdo = new PDO("sqlite:tb.sqlite");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);

    // tb テーブルにおいて指定された ID が存在するか確認
    $st_tb_check = $pdo->prepare("SELECT COUNT(*) FROM tb WHERE id = :id");
    $st_tb_check->bindParam(':id', $id, PDO::PARAM_INT);
    $st_tb_check->execute();
    $count_tb = $st_tb_check->fetchColumn();

    if ($count_tb == 0) {
        // 指定された ID が tb テーブルに存在しない場合の処理
        echo "<p>そのIDはありません。</p>";
    } else {
        // mytb テーブルにおいて指定された ID が存在するか確認
        $st_mytb_check = $pdo->prepare("SELECT COUNT(*) FROM mytb WHERE id = :id");
        $st_mytb_check->bindParam(':id', $id, PDO::PARAM_INT);
        $st_mytb_check->execute();
        $count_mytb = $st_mytb_check->fetchColumn();

        if ($count_mytb == 0) {
            // すでに登録済みでない場合の処理
            $st2 = $pdo->prepare("INSERT INTO mytb (id) VALUES (:id)");
            $st2->bindParam(':id', $id, PDO::PARAM_INT);

            if ($st2->execute()) {
                echo "<p>ID {$id} を mytb に追加しました。</p>";
            } else {
                print_r($st2->errorInfo());
            }
        } else {
            // すでに登録済みの場合の処理
            echo "<p>ID {$id} はすでに登録されています。</p>";
        }
    }
}
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Table with Links</title>

    <meta name="description" content="書籍「動くWebデザインアイディア帳」のサンプルサイトです">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!--==============レイアウトを制御する独自のCSSを読み込み===============-->
  <link rel="stylesheet" type="text/css" href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/reset.css">
  <link rel="stylesheet" type="text/css" href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/5-1-26/css/5-1-26.css">
  <link rel="stylesheet" href="top-style.css">
  <link rel="stylesheet" href="schedule.css">
  <style>
        /* テーブル全体のスタイル */
        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }

        /* テーブルのセル共通のスタイル */
        td, th {
            border: 1px solid #dddddd;
            text-align: center;
            padding: 8px;
        }

        /* テーブルのヘッダーのスタイル */
        th {
            background-color: #f2f2f2;
        }

        /* テーブルのリンクのスタイル */
        td a {
            color: #76503e;
            text-decoration: none;
        }

        td a:hover {
            text-decoration: underline;
        }

        /* テーブルのセルの背景色を交互に変更する */
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
<header id="header">
    <h1>UniConnect</h1>
    <nav id="g-nav">
      <ul>
        <!-- 各リンクのhref属性を別のプログラムに変更 -->
        <li><a href="top-page.php">Home</a></li>
        <li><a href="rakutennbook.php">Book</a></li>
        <li><a href="ToDo.php">To Do List</a></li>
        <li><a href="timeTable.php">Schedule</a></li>
        <li><a href="question_form.php">Contact</a></li>
      </ul>
    </nav>
    
  </header>
<main>
  <section>
  <h2 class="heading-031">Time Schedule</h2>
<table border="1">
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Week</th>
        <th>Number</th>
        <th>Teacher</th>
        <th>Place</th>
        <th>Type</th>
        <th>Link</th>
    </tr>
    <?php foreach ($data as $row): ?>
        <tr>
            <td><?= h($row['id']) ?></td>
            <td><?= h($row['name']) ?></td>
            <td><?= h($row['week']) ?></td>
            <td><?= h($row['number']) ?></td>
            <td><?= h($row['teacher']) ?></td>
            <td><?= h($row['place']) ?></td>
            <td><?= h($row['type']) ?></td>
            <td><a href="detail.php?id=<?= h($row['id']) ?>">詳細</a></td>
        </tr>
    <?php endforeach; ?>
</table>
<br>
<form method="POST" action="">
    <span class="textbox-002-label">追加する授業ID</span>
    <input type="text" class="textbox-002" name="id" > <!-- この部分は適切なフォーム要素に置き換えてください -->
    <br><br>
    <div class="button_solid017">
    <input type="submit" value="追加">
    </div>
    <br>
    <a href="timeTable.php">トップに戻る</a>
</form>

<?php
// $pdoには適切なPDOオブジェクトが含まれていると仮定しています

// 1. パラメータなしで準備されたステートメントを使用する
$st3 = $pdo->query("SELECT * FROM mytb");
$st4 = $pdo->query("SELECT * FROM tb");

// 2. 結果を取得
$mytbData = $st3->fetchAll(PDO::FETCH_ASSOC);
$tbData = $st4->fetchAll(PDO::FETCH_ASSOC);

echo "<br><h2>履修した科目</h2>";

// 3. 結果が空でない場合のみテーブルを表示
if (!empty($mytbData)) {
    echo "<table border='1'>";
    echo "<tr><th>ID</th><th>Name</th></tr>";

    foreach ($mytbData as $mytbRow) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($mytbRow['id']) . "</td>";

        // 一致する行を検索
        $matchingRow = array_filter($tbData, function ($row) use ($mytbRow) {
            return $row['id'] == $mytbRow['id'];
        });

        // 一致する行があれば、そのnameを表示
        if (!empty($matchingRow)) {
            $matchingRow = reset($matchingRow);
            echo "<td>" . htmlspecialchars($matchingRow['name']) . "</td>";
        } else {
            echo "<td>該当なし</td>";
        }

        echo "</tr>";
    }

    echo "</table>";
} else {
    // 4. 結果が空の場合のメッセージを表示
    echo "<p>mytbにデータが見つかりませんでした。</p>";
}
?>
</section>
</main>
<footer id="footer">
    <small>&copy; copyright.</small>  
  </footer>
</body>
</html>
