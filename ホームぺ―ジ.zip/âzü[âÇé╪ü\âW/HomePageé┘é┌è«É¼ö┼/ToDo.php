<?php
ini_set('display_errors', "On");
error_reporting(E_ALL);

try {
    // SQLiteデータベースへの接続
    $db = new PDO('sqlite:todo.sqlite');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // テーブルが存在しない場合は作成
    $db->exec('CREATE TABLE IF NOT EXISTS tasks (id INTEGER PRIMARY KEY, task TEXT)');
} catch (PDOException $e) {
    die('Connection failed: ' . $e->getMessage());
}

// タスクのリスト
$tasks = [];

// タスクの追加
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_task'])) {
    $newTask = $_POST['task'];
    if (!empty($newTask)) {
        // データベースにタスクを追加
        $stmt = $db->prepare('INSERT INTO tasks (task) VALUES (:task)');
        $stmt->bindParam(':task', $newTask);
        $stmt->execute();
    }
}

// タスクの取得
$stmt = $db->query('SELECT * FROM tasks');
$tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);

// タスクの削除
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_tasks'])) {
    foreach ($_POST['delete'] as $taskId) {
        // データベースからタスクを削除
        $stmt = $db->prepare('DELETE FROM tasks WHERE id = :id');
        $stmt->bindParam(':id', $taskId);
        $stmt->execute();
    }
    // 削除後、新しいタスクリストを取得
    $stmt = $db->query('SELECT * FROM tasks');
    $tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// データベース接続を閉じる
$db = null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ToDo List</title>

    <meta name="description" content="書籍「動くWebデザインアイディア帳」のサンプルサイトです">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--==============レイアウトを制御する独自のCSSを読み込み===============-->
    <link rel="stylesheet" type="text/css" href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/reset.css">
    <link rel="stylesheet" type="text/css" href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/5-1-26/css/5-1-26.css">
    <link rel="stylesheet" href="top-style.css">
    <link rel="stylesheet" href="ToDo.css">

</head>

<body>
<header id="header">
    <h1>UniConnect</h1>
    <nav id="g-nav">
      <ul>
        <!-- 各リンクのhref属性を別のプログラムに変更 -->
        <li><a href="top-page.php">Home</a></li>
        <li><a href="rakutennbook.php">Book</a></li>
        <li><a href="ToDo.php">To Do List</a></li>
        <li><a href="timeTable.php">Schedule</a></li>
        <li><a href="question_form.php">Contact</a></li>
      </ul>
    </nav>
    
  </header>
    <main>
        <section>
            <h2 class="heading-031">MY  TODO  LIST</h2>
            <form method="post" action="">
            <?php
            // タスクの表示
            if (!empty($tasks)) {
                echo '<ul>';
                foreach ($tasks as $task) {
                    echo '<div class="checkbox-label">';
                    echo '<input type="checkbox" id="task_' . $task['id'] . '" name="delete[]" value="' . $task['id'] . '">';
                    echo '<label for="task_' . $task['id'] . '">' . htmlspecialchars($task['task']) . '</label>';
                    echo '</div>';
                }
                echo '</ul>';
                echo '<div class="button_solid017"><button type="submit" name="delete_tasks">選択したタスクを削除</button></div>';
            } else {
                echo '<p>タスクはありません！たまにはゆっくり休んでみませんか？</p>';
            }
            ?>

            </form>

            <form method="post" action="">
                <label class="label-new-task">
                    <span class="textbox-002-label">New Task</span>
                    <input type="text" class="textbox-002" name="task" placeholder="例）WP実習最終課題"/>
                </label>
                <div class="button_solid017">
                    <button type="submit" name="add_task">タスクを追加</button>
                </div>
            </form>
        </section>
    </main>
    <footer id="footer">
        <small>&copy; copyright.</small>
    </footer>
</body>
</html>
