<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>楽天ブックス検索</title>
  <meta name="description" content="書籍「動くWebデザインアイディア帳」のサンプルサイトです">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!--==============レイアウトを制御する独自のCSSを読み込み===============-->
  <link rel="stylesheet" type="text/css" href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/reset.css">
  <link rel="stylesheet" type="text/css" href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/5-1-26/css/5-1-26.css">
  <link rel="stylesheet" href="rakutenn.css">
  <link rel="stylesheet" href="top-style.css">
</head>
<body>
<header id="header">
    <h1>UniConnect</h1>
    <nav id="g-nav">
      <ul>
        <!-- 各リンクのhref属性を別のプログラムに変更 -->
        <li><a href="top-page.php">Home</a></li>
        <li><a href="rakutennbook.php">Book</a></li>
        <li><a href="ToDo.php">To Do List</a></li>
        <li><a href="timeTable.php">Schedule</a></li>
        <li><a href="question_form.php">Contact</a></li>
      </ul>
    </nav>
  </header>
  <main>
  <section>
<?php
// 楽天のAPI設定
$rakuten_api_url = 'https://app.rakuten.co.jp/services/api/BooksBook/Search/20170404';
$rakuten_app_id = '1065515394156514169'; // ここにあなたの楽天のアプリケーションIDを設定してください
?>
<!-- HTMLフォーム -->
<form action="rakutennbook.php" method="get">
<form action="rakutennbook.php" method="get" class="nice-wrap">
    <h2 class="heading-031">書籍検索</h2>
    <label for="keyword" class="textbox-002-label">キーワード:</label>
    <input type="text" name="keyword" id="keyword" class="textbox-002" required>
    <br>
    <label for="money" class="textbox-002-label">金額:</label>
    <select name="money" class="textbox-002">
        <option value="1000000" selected>未選択</option>
        <option value="2000"> ~2000</option>
        <option value="4000"> ~4000 </option>
        <option value="6000">~6000 </option>
    </select>
    <input type="submit" value="検索" class="button_solid017"><br>
</form>

<?php
// 書籍検索関数
function searchBooks($keyword) {
    global $rakuten_api_url, $rakuten_app_id;
    $query_params = array(
        'format' => 'json',
        'applicationId' => $rakuten_app_id,
        'title' => $keyword,
    );

    $url = $rakuten_api_url . '?' . http_build_query($query_params);

    $response = file_get_contents($url);

    return json_decode($response, true);
}

// 書籍情報表示関数
function displayBookInfo($book) {
    echo '<img src="' . $book['mediumImageUrl'] . '" alt="Book Cover"><br>';
    echo 'タイトル: ' . $book['title'] . '<br>';
    echo '著者: ' . $book['author'] . '<br>';
    echo '金額: ' . $book['itemPrice'] . '円<br>';
    echo '<a href="' . $book['itemUrl'] . '" target="_blank">詳細を見る</a><br>';
    echo '<hr>';
}
// メイン処理
if (isset($_GET['keyword'])) {
    $keyword = $_GET['keyword'];
    $books = searchBooks($keyword);
    if (isset($_GET['money'])) {
        $money = $_GET['money'];
        if (isset($books['Items']) && is_array($books['Items'])) {
            foreach ($books['Items'] as $book) {
                if ($book['Item']['itemPrice'] <= $money) {
                    displayBookInfo($book['Item']);
                }
            }
        } else {
            echo '検索結果がありません。';
        }
    }
}
?>
</section>
</main>
<footer id="footer">
    <small>&copy; copyright.</small>  
  </footer>
</body>
</html>
