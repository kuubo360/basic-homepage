<!DOCTYPE html>
<html lang="ja">
<?php
function h($str) { return htmlspecialchars($str, ENT_QUOTES, "UTF-8"); }

// POSTリクエストがあるかどうかを確認
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // フォームから送信されたデータを取得
    $name = $_POST['name'];
    $week = $_POST['week'];
    $number = $_POST['number'];
    $teacher = $_POST['teacher'];  // 修正: 'teacher' の変数名を修正
    $place = $_POST['place'];
    $type = $_POST['type'];

    // データベースに接続
    $pdo = new PDO("sqlite:tb.sqlite");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);

    // プリペアドステートメントを用意
    $stmt = $pdo->prepare("INSERT INTO tb (name, week, number, teacher, place, type) VALUES (:name, :week, :number, :teacher, :place, :type)");

    // プリペアドステートメントに値をバインド
    $stmt->bindParam(':name', $name, PDO::PARAM_STR);
    $stmt->bindParam(':week', $week, PDO::PARAM_INT);  // 修正: 'week' は文字列として扱う
    $stmt->bindParam(':number', $number, PDO::PARAM_INT);
    $stmt->bindParam(':teacher', $teacher, PDO::PARAM_STR);  // 修正: 'teacher' を正しくバインド
    $stmt->bindParam(':place', $place, PDO::PARAM_STR);
    $stmt->bindParam(':type', $type, PDO::PARAM_INT);  // 修正: 'type' は文字列として扱う

    // プリペアドステートメントを実行
    $stmt->execute();
}

// データベースから全データを取得
$pdo = new PDO("sqlite:tb.sqlite");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
$st = $pdo->query("SELECT * FROM tb");
$data = $st->fetchAll();
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Table with Links</title>

    <meta name="description" content="書籍「動くWebデザインアイディア帳」のサンプルサイトです">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!--==============レイアウトを制御する独自のCSSを読み込み===============-->
  <link rel="stylesheet" type="text/css" href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/reset.css">
  <link rel="stylesheet" type="text/css" href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/5-1-26/css/5-1-26.css">
  <link rel="stylesheet" href="top-style.css">
  <link rel="stylesheet" href="schedule.css">
  <style>
        /* テーブル全体のスタイル */
        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }

        /* テーブルのセル共通のスタイル */
        td, th {
            border: 1px solid #dddddd;
            text-align: center;
            padding: 8px;
        }

        /* テーブルのヘッダーのスタイル */
        th {
            background-color: #f2f2f2;
        }

        /* テーブルのリンクのスタイル */
        td a {
            color: #0066cc;
            text-decoration: none;
        }

        td a:hover {
            text-decoration: underline;
        }

        /* テーブルのセルの背景色を交互に変更する */
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
<header id="header">
    <h1>UniConnect</h1>
    <nav id="g-nav">
      <ul>
        <!-- 各リンクのhref属性を別のプログラムに変更 -->
        <li><a href="top-page.php">Home</a></li>
        <li><a href="rakutennbook.php">Book</a></li>
        <li><a href="ToDo.php">To Do List</a></li>
        <li><a href="timeTable.php">Schedule</a></li>
        <li><a href="question_form.php">Contact</a></li>
      </ul>
    </nav>
    
  </header>
<main>
  <section>
  <h2 class="heading-031">Time Schedule</h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>授業名</th>
            <th>曜日</th>
            <th>時限目</th>
            <th>先生</th>
            <th>場所</th>
            <!--th>種類</th-->
        </tr>
        <?php
        foreach ($data as $row) {
            echo "<tr>";
            echo "<td>" . h($row['id']) . "</td>";
            echo "<td>" . h($row['name']) . "</td>";
            echo "<td>" . h($row['week']) . "</td>";
            echo "<td>" . h($row['number']) . "</td>";
            echo "<td>" . h($row['teacher']) . "</td>";
            echo "<td>" . h($row['place']) . "</td>";
           // echo "<td>" . h($row['type']) . "</td>";
            echo "</tr>";
        }
        ?>
    </table>
    <br>
    <form method="POST" > <!-- 修正: actionをtimeTable.phpに変更 -->
        <label for="name">授業名:</label>
        <input type="text" class="textbox-002" id="name" name="name" required>
        <br>

        <label for="week">曜日:</label>
        <input type="text" class="textbox-002" id="week" name="week" required>
        <br>

        <label for="number">時限目:</label>
        <input type="text" class="textbox-002" id="number" name="number" required>
        <br>

        <label for="teacher">先生:</label>
        <input type="text" class="textbox-002" id="teacher" name="teacher" required>
        <br>

        <label for="place">場所:</label>
        <input type="text" class="textbox-002" id="place" name="place" required>
        <br>

        <!--label for="type">種類:</label>
        <input type="text" class="textbox-002" id="type" name="type" required>
        <br><br-->
        <div class="button_solid017">
        <input type="submit" value="追加">
        <a href="timeTable.php">トップに戻る</a>
    </div>
    </form>
    </section>
</main>
<footer id="footer">
    <small>&copy; copyright.</small>  
  </footer>
</body>
</html>
