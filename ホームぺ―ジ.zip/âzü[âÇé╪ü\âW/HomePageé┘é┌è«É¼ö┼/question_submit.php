<?php
function h($str) { return htmlspecialchars($str, ENT_QUOTES, "UTF-8"); }
session_start();
date_default_timezone_set("Asia/Tokyo");

if(isset($_POST["name"]) && isset($_POST["mail"]) && isset($_POST["message"])) {
    $name = h($_POST["name"]);
    $mail = h($_POST["mail"]);
    $message = h($_POST["message"]);
    $time = date("Y-m-d H:i");
    $pdo = new PDO("sqlite:question.sqlite");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
    $st = $pdo->prepare("INSERT INTO content(name, mail, message, time) VALUES(? , ?, ?, ?)");
    $st->execute(array($name, $mail, $message, $time));
    $result = "お問い合わせありがとうございました。";
} else {
    $result = "入力内容に誤りがあります。";
}
?>

<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="utf-8">
    <title>問い合わせ登録</title>
    <link rel="stylesheet" type="text/css" href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/reset.css">
  <link rel="stylesheet" type="text/css" href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/5-1-26/css/5-1-26.css">
  <link rel="stylesheet" href="question_form.css">
  <link rel="stylesheet" href="top-style.css">
</head>
<style>
    section {
        text-align: center;
    }

    a {
        display: inline-block;
        margin-top: 20px; 
    }
</style>

<body>
<header id="header">
    <h1>UniConnect</h1>
    <nav id="g-nav">
      <ul>
        <!-- 各リンクのhref属性を別のプログラムに変更 -->
        <li><a href="top-page.php">Home</a></li>
        <li><a href="rakutennbook.php">Book</a></li>
        <li><a href="ToDo.php">To Do List</a></li>
        <li><a href="timeTable.php">Schedule</a></li>
        <li><a href="question_form.php">Contact</a></li>
      </ul>
    </nav>
    
  </header>
  <main>
    <section>
    <h2><?php echo $result; ?></h2>
    <a href="question_form.php">お問い合わせページに戻る</a>
</section>
</main>
</body>
</html>
