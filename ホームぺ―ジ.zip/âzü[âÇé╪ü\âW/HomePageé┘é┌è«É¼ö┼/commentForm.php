<?php
  function h($str) { return htmlspecialchars($str, ENT_QUOTES, "UTF-8"); }
  $classId = isset($_GET["classId"]) ? (int)$_GET["classId"] : 0;
  if (!$classId) {
    // Display an error message and handle the error as needed
    die("Error: Article ID is not set or invalid.");
}
?>
<!DOCTYPE html>
<html lang="ja">
  <head>
    <meta charset="utf-8">
    <title>My Blog - コメント投稿</title> 

    <meta name="description" content="書籍「動くWebデザインアイディア帳」のサンプルサイトです">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!--==============レイアウトを制御する独自のCSSを読み込み===============-->
  <link rel="stylesheet" type="text/css" href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/reset.css">
  <link rel="stylesheet" type="text/css" href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/5-1-26/css/5-1-26.css">
  <link rel="stylesheet" href="top-style.css">   
  <link rel="stylesheet" href="schedule.css">   
  </head>
  <body>
  <header id="header">
    <h1>UniConnect</h1>
    <nav id="g-nav">
      <ul>
        <!-- 各リンクのhref属性を別のプログラムに変更 -->
        <li><a href="top-page.php">Home</a></li>
        <li><a href="rakutennbook.php">Book</a></li>
        <li><a href="ToDo.php">To Do List</a></li>
        <li><a href="timeTable.php">Schedule</a></li>
        <li><a href="question_form.php">Contact</a></li>
      </ul>
    </nav>
    
  </header>
<main>
  <section>
  <h2 class="heading-031">Time Schedule</h2>
  <form action="commentSubmit.php" method="get">
  <!--span class="textbox-002-label">主題</span>
  <input type="text" class="textbox-002" name="name"-->
  <span class="textbox-002-label">コメント内容</span>
  <textarea class="textbox-002" name="body"></textarea>
  <input type="hidden" name="classId" value="<?php echo h($classId); ?>">
  <div class="button_solid017">
  <input type="submit" value="送信">
</div>
  </section>
</main>
<footer id="footer">
    <small>&copy; copyright.</small>  
  </footer>
  </body>
</html>