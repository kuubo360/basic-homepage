

<?php
  function h($str) { return htmlspecialchars($str, ENT_QUOTES, "UTF-8"); }

  if (isset($_GET["classId"]) /*&& isset($_GET["name"])*/ && isset($_GET["body"])) {
    $classId = $_GET["classId"];
    $name = $_GET["name"];
      $body = $_GET["body"];

  
      $pdo = new PDO("sqlite:tb.sqlite");
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
  $st = $pdo->prepare("INSERT INTO comment1(classId,text) VALUES(?, ?)");
  $st->execute(array($classId, $body));

      $result = "登録しました。";
  }
  else {
    $result = "記事の内容がありません。";
  }
?>
<!DOCTYPE html>
<html lang="ja">
  <head>
    <meta charset="utf-8">
    <title>My Blog - コメント登録</title>
         
    <meta name="description" content="書籍「動くWebデザインアイディア帳」のサンプルサイトです">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!--==============レイアウトを制御する独自のCSSを読み込み===============-->
  <link rel="stylesheet" type="text/css" href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/reset.css">
  <link rel="stylesheet" type="text/css" href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/5-1-26/css/5-1-26.css">
  <link rel="stylesheet" href="top-style.css">
  <link rel="stylesheet" href="schedule.css">
  </head>
  <body>
  <header id="header">
    <h1>UniConnect</h1>
    <nav id="g-nav">
      <ul>
        <!-- 各リンクのhref属性を別のプログラムに変更 -->
        <li><a href="top-page.php">Home</a></li>
        <li><a href="rakutennbook.php">Book</a></li>
        <li><a href="ToDo.php">To Do List</a></li>
        <li><a href="timeTable.php">Schedule</a></li>
        <li><a href="question_form.php">Contact</a></li>
      </ul>
    </nav>
    
  </header>
<main>
  <section>
  <h2 class="heading-031">Time Schedule</h2>
  <div>
    <?php
      // 処理結果を表示
      echo $result;
    ?>
  </div>
    <div>
    <!-- ブログのページに戻るリンク -->
    <a href="timetable.php">ブログのページに戻る</a>
  </div>
  </section>
</main>
<footer id="footer">
    <small>&copy; copyright.</small>  
  </footer>
  </body>
</html>