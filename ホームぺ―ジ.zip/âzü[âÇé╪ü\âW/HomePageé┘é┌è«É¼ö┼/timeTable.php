<!DOCTYPE html>
<html lang="ja">
<?php
function h($str) { return htmlspecialchars($str, ENT_QUOTES, "UTF-8"); }
$pdo = new PDO("sqlite:tb.sqlite");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
$st = $pdo->query("SELECT * FROM tb");
$data = $st->fetchAll();
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Table with Links</title>

    <meta name="description" content="書籍「動くWebデザインアイディア帳」のサンプルサイトです">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!--==============レイアウトを制御する独自のCSSを読み込み===============-->
  <link rel="stylesheet" type="text/css" href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/reset.css">
  <link rel="stylesheet" type="text/css" href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/5-1-26/css/5-1-26.css">
  <link rel="stylesheet" href="top-style.css">
  <link rel="stylesheet" href="schedule.css">

  <style>
        /* テーブル全体のスタイル */
        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }

        /* テーブルのセル共通のスタイル */
        td, th {
            border: 1px solid #dddddd;
            text-align: center;
            padding: 8px;
        }

        /* テーブルのヘッダーのスタイル */
        th {
            background-color: #f2f2f2;
        }

        /* テーブルのリンクのスタイル */
        td a {
            color: #76503e;
            text-decoration: none;
        }

        td a:hover {
            text-decoration: underline;
        }

        /* テーブルのセルの背景色を交互に変更する */
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
<header id="header">
    <h1>UniConnect</h1>
    <nav id="g-nav">
      <ul>
        <!-- 各リンクのhref属性を別のプログラムに変更 -->
        <li><a href="top-page.php">Home</a></li>
        <li><a href="rakutennbook.php">Book</a></li>
        <li><a href="ToDo.php">To Do List</a></li>
        <li><a href="timeTable.php">Schedule</a></li>
        <li><a href="question_form.php">Contact</a></li>
      </ul>
    </nav>
    
  </header>
<main>
  <section>
  <h2 class="heading-031">Time Schedule</h2>
    <table border="1">
        <?php
        // 行数と列数の設定
        $rows = 7;
        $cols = 6;
        $WeekArray = array(
            '時限/曜日',
            '月',
            '火',
            '水',
            '木',
            '金',
            '土'
        );
        echo "<tr>";
        for ($k = 0; $k < $rows; $k++) {
            echo "<td>{$WeekArray[$k]}</td>";
        }
        echo "</tr>";

        // 行ループ
        for ($i = 1; $i <= $rows; $i++) {
            echo "<tr>";
            
            // 列ループ
            for ($j = 1; $j <= $cols; $j++) {
                if ($j == 1) {
                    echo "<td>{$i}限</td>";
                }

                // tbテーブルのデータと比較して、一致する場合はnameを表示
                $found = false;
                foreach ($data as $row) {
                    if ($row['week'] == $j && $row['number'] == $i) {
                        echo "<td><a href='detail.php?row={$i}&col={$j}'>" . h($row['name']) . "</a></td>";
                        $found = true;
                        break;
                    }
                }

                // 各セルにリンクを追加
                if (!$found) {
                    echo "<td><a href='classes.php?row={$i}&col={$j}'> {$j}-{$i}</a></td>";
                }
            }
            echo "</tr>";
        }
        ?>
    </table>
    <br>
  <!--<a href='selectTimeTable.php'>授業追加システム</a>-->
   <a href='classData.php'>授業追加</a>
  <a href='deleteTimeTable.php'>授業削除</a>
    </section>
</main>
<footer id="footer">
    <small>&copy; copyright.</small>  
  </footer>
</body>
</html>
